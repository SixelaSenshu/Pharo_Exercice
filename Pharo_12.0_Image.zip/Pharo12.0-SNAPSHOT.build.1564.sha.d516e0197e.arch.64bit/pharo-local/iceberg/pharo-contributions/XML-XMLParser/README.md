# XML-XMLParser

[![Test](https://github.com/pharo-contributions/XML-XMLParser/actions/workflows/test.yml/badge.svg)](https://github.com/pharo-contributions/XML-XMLParser/actions/workflows/test.yml)

XML Parser for [Pharo](http://www.pharo.org)

[![Pharo 7](https://img.shields.io/badge/Pharo-7.0-%23aac9ff.svg)](https://pharo.org/download)
[![Pharo 8](https://img.shields.io/badge/Pharo-8.0-%23aac9ff.svg)](https://pharo.org/download)
[![Pharo 9](https://img.shields.io/badge/Pharo-9.0-%23aac9ff.svg)](https://pharo.org/download)
[![Pharo 10](https://img.shields.io/badge/Pharo-10-%23aac9ff.svg)](https://pharo.org/download)
[![Pharo 11](https://img.shields.io/badge/Pharo-11-%23aac9ff.svg)](https://pharo.org/download)
[![Pharo 12](https://img.shields.io/badge/Pharo-12-%23aac9ff.svg)](https://pharo.org/download)
[![Pharo 13](https://img.shields.io/badge/Pharo-13-%23aac9ff.svg)](https://pharo.org/download)

## Description

`XMLParser` provides validating SAX and DOM parsers for well-formed XML documents.
It also provides a DOM API for manipulating documents, namespace support, and an
optional `XMLWriter` for writing documents. Validation and namespace checking are
enabled by default, but not resolution of external entities.

Implements:

- http://www.w3.org/TR/REC-xml/
- http://www.w3.org/TR/REC-xml-names/
- http://www.w3.org/TR/xml-id/
- http://www.w3.org/TR/xmlbase/

## Installation

```Smalltalk
Metacello new
  baseline: 'XMLParser';
  repository: 'github://pharo-contributions/XML-XMLParser/src';
  load.
```

## How to use

Use the `XMLDOMParser` to parse a URL:

```Smalltalk
(XMLDOMParser parseURL: 'https://www.w3schools.com/xml/simple.xml') inspect
```

or give an XML file directly:

```Smalltalk
|xmlString|
xmlString := '<?xml version="1.0" encoding="UTF-8"?>
<countries>
  <country code="af" handle="afghanistan" continent="asia" iso="4">Afghanistan</country>
  <country code="al" handle="albania" continent="europe" iso="8">Albania</country>
  <country code="dz" handle="algeria" continent="africa" iso="12">Algeria</country>
</countries>'.

(XMLDOMParser parse: xmlString) document root nodes inspect
```

Check [https://montyos.wordpress.com](https://montyos.wordpress.com) for more
examples and descriptions.

## Screenshot

![alt text](doc/images/screen001.png "Screenshot")

## LICENSE

[MIT License](LICENSE)

## History

This project was migrated from [http://smalltalkhub.com/#!/~PharoExtras/XMLParser](http://smalltalkhub.com/#!/~PharoExtras/XMLParser)
