# Athens-SVG
SVG support for Athens framework in Pharo

Based on the obsolete Monticello repository http://www.smalltalkhub.com/mc/Pharo/Athens/main

## Installation

```Smalltalk
Metacello new
	baseline: 'AthensSVG';
	repository: 'github://pharo-contributions/Athens-SVG/src';
	load.
```	
